<!DOCTYPE html>
<html lang="en">

<head>
     <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ab102324b401e45400de2fa/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
	<title>राजस्थान a Travel Category Bootstrap Responsive Website Template | About :: w3layouts</title>
	<!-- Meta Tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="राजस्थान Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta Tags -->
	<!-- Style-sheets -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all">
	<link rel="stylesheet" href="css/team.css" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!-- // Style-sheets -->
	<!-- Online-fonts -->
	<link href="//fonts.googleapis.com/css?family=Montserrat:100,200,400,500,600" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
	<!--// Online-fonts -->

</head>

<body>
    <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.12&appId=122697887880133&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
	<!--Header-->
	<div class="header inn-banner" id="home">
		<!--top-bar-w3-agile-->
		<div class="top-bar-w3-agile">
			<div class="container">
				<div class="header-top-agileits">
					<div class="agile_forms">
						<p><span class="fa fa-map-marker" aria-hidden="true"></span></p>
					</div>
					<ul class="top-right-info-w3ls">
						<li><a href="https://www.facebook.com/rajasthantourism/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="https://mail.gov.in/iwc_static/c11n/allDomain/layout/login_gov2.jsp?lang=en-US&3.0.1.2.0_15121607&svcs=abs,mail,smime,calendar,c11n""><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						<li><a href="https://twitter.com/rajgovofficial?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="https://in.pinterest.com/diprrajasthan/"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>

					</ul>
					<div class="clearfix"></div>
				</div>
				<div class="header-nav">
					<nav class="navbar navbar-default">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
							<h1><a class="navbar-brand" href="index.html">रा<span>जस्थान</span></a></h1>
						</div>
						<!-- Collect the nav links, forms, and other content for toggling -->
							<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
							<nav class="cl-effect-15" id="cl-effect-15">
								<ul>
									<li><a href="index.html" class="active" data-hover="Home">Home</a></li>
									<li><a href="about.html" data-hover="About">About</a></li>
													
													
																		<li class="dropdown menu__item">
									<a href="#" class="dropdown-toggle menu__link" data-toggle="dropdown" data-hover="Apply" role="button" aria-haspopup="true"
										    aria-expanded="false">Apply<span class="caret"></span></a>
										<ul class="dropdown-menu">
										    
											<li><a href="guide.html">Guide</a>
											</li>
											
											
											
											
											
											
											
											
											
											<li><a href="guard.html">Guards</a></li>
											
												<li><a href="lawyer.html">Lawyers</a></li>
										</ul>
									</li>
									<li><a href="home2.php" data-hover="Login">Login</a></li>
										<li><a href="pooling.php" data-hover="Pooling">Pooling</a></li>
								</ul>
							</nav>
						</div>
					</nav>
					<div class="w3ls_search">
						<div class="cd-main-header">
							<ul class="cd-header-buttons">
								<li><a class="cd-search-trigger" href="#cd-search"> <span></span></a></li>
							</ul>
							<!-- cd-header-buttons -->
						</div>
						<div id="cd-search" class="cd-search">
							<form action="#" method="post">
								<input name="Search" type="search" placeholder="Search...">
							</form>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		<!--//top-bar-w3-agile-->
	</div>
	<center></a><div class="fb-comments" data-href="https://developers.facebook.com/docs/plugins/comments#configurator" data-numposts="8"></div></center>
	<!--//Header-->
	<!-- //Modal1 -->
	<!-- //About -->
	<!--sevices-->
	<div class="sevices-w3layouts" id="services">
		<div class="container">
			<h3 class="tittle white">Why we are the best</h3>
			<div class="row">
				<div class="col-md-4 sevices-grid text-right">
					<div class="icon">
						<span class="fa fa-plane" aria-hidden="true"></span>
						<h4></h4>
					</div>
					<p class="para-agileits">We provide you safe and secure travelling facilities.</p>

				</div>
				<div class="col-md-4 sevices-grid text-center">
					<div class="icon">
						<span class="fa fa-thumbs-up" aria-hidden="true"></span>
						<h4>Handpicked Hotels</h4>
					</div>
					<p class="para-agileits">You can order your hotel online at the minimum cost.</p>
				</div>
				<div class="col-md-4 sevices-grid text-left">
					<div class="icon">
						<span class="fa fa-users" aria-hidden="true"></span>
						<h4>Nice Support</h4>
					</div>
					<p class="para-agileits">Helpline number available 24*7.</p>
				</div>
				<div class="col-md-6 sevices-grid text-right">
					<div class="icon">
						<span class="fa fa-briefcase" aria-hidden="true"></span>
						<h4>World class services</h4>
					</div>
					<p class="para-agileits">We provide you with the best services.</p>
				</div>
				<div class="col-md-6 sevices-grid text-left">
					<div class="icon">
						<span class="fa fa-credit-card-alt" aria-hidden="true"></span>
						<h4>Best Price Guarantee</h4>
					</div>
					<p class="para-agileits">The prices are as low as possible.</p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!--//sevices-->
	<!-- team -->
	
	<!-- team -->

	<!-- Footer -->
	<div class="reach-wthree">
		<div class="container">
			<h3></h3>
			<div class="reach-right-agileits-w3layouts">
				<p></p>
				<p></p>
				<h6><span class="fa fa-phone" aria-hidden="true"></span> (+91) 1800-456-7890</h6>
			</div>
		</div>
	</div>
	<div class="w3l_footer_agileinfo">
		<div class="container">
			<div class="col-md-3 mailadd-w3ls">
				<p><span class="fa fa-envelope" aria-hidden="true"></span><a href="mailto:info@example.com">tourism.rajasthan@example.com</a></p>
			</div>
			<div class="col-md-6 botttom-nav-agileits">
				<ul class="nav-w3ls">
					<li><a href="index.html">Home</a></li>
					<li><a href="about.html">About</a></li>
					
					<li><a href="contact.html">Contact</a></li>
				</ul>
			</div>
			<div class="col-md-3 w3l-social">
				<ul class="top-right-info-w3ls">
					<li><a href="https://www.facebook.com/rajasthantourism/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a href="https://mail.gov.in/iwc_static/c11n/allDomain/layout/login_gov2.jsp?lang=en-US&3.0.1.2.0_15121607&svcs=abs,mail,smime,calendar,c11n"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
					<li><a href="https://twitter.com/rajgovofficial?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a href="https://in.pinterest.com/diprrajasthan/"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
				</ul>
			</div>

			<div class="clearfix"> </div>
		</div>
	</div>
	
	<script charset="utf-8" type="text/javascript" src="http://movetotravel.com/iframe.js"> </script>
	
	<!-- //Footer -->
	<!--Copy-right-->
	<div class="copy">
		<div class="container">
			<h2><a href="index.html"><span>रा</span>जस्थान </a></h2>
			<p>© 2017 राजस्थान . All Rights Reserved | Design by  </p>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!--// Copy-right -->

	<!-- js -->
	<script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
	<!-- start-smoth-scrolling -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();
				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- start-smoth-scrolling -->
	<!-- About-Responsiveslides -->
	<script src="js/responsiveslides.min.js"></script>
	<script>
		// You can also use "$(window).load(function() {"
		$(function () {
			// Slideshow 4
			$("#slider3").responsiveSlides({
				auto: false,
				pager: true,
				nav: false,
				speed: 500,
				namespace: "callbacks",
				before: function () {
					$('.events').append("<li>before event fired.</li>");
				},
				after: function () {
					$('.events').append("<li>after event fired.</li>");
				}
			});
		});
	</script>
	<!--// About-Responsiveslides -->

	<!--search-bar-->
	<script src="js/main.js"></script>
	<!--//search-bar-->
	<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function () {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
			$().UItoTop({
				easingType: 'easeOutQuart'
			});
		});
	</script>

	<a href="#home" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!-- //smooth scrolling -->
	<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>

</body>

</html>